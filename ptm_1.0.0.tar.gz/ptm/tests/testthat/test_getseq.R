library(ptm)
context("Sequence Recovering Functions Tests")

## ---------------------------------------------- ##
#               Testing get.seq                    #
## ---------------------------------------------- ##
test_that("get.seq() works properly in mode string",{

  skip_on_cran()
  skip_on_travis()

  expect_equal(nchar(get.seq('P01009')), 418)
  expect_equal(nchar(get.seq('P01009', db = 'metosite')), 394)
  expect_equal(nchar(get.seq('3CWM', db = 'pdb')), 394)
  expect_equal(nchar(get.seq('2OCC.C', db = 'pdb')), 261)
})


test_that("get.seq() works properly in mode array",{

  skip_on_cran()
  skip_on_travis()

  t <- get.seq('P01009', as.string = FALSE)

  expect_is(t, 'matrix')
  expect_equal(ncol(t), 418)
  expect_equal(t[28], 'Q')
  expect_equivalent(get.seq('3CWM', db = 'pdb', as.string = FALSE)[4], 'Q')

  t <- get.seq('P01009', db = 'metosite', as.string = FALSE)
  expect_is(t, 'character')
  expect_equal(length(t), 394)
  expect_equivalent(t[4], 'Q')
})


test_that('get.seq() works properly with KEGG', {

  skip_on_cran()
  skip_on_travis()

  seq <- get.seq('hsa:5265', 'kegg-nt')

  expect_equal(nchar(seq), 1257)
})


## ---------------------------------------------- ##
#             Testing prot2codon                   #
## ---------------------------------------------- ##
test_that("prot2codon() works properly",{

  skip_on_cran()
  skip_on_travis()

  a <- prot2codon("P01009")
  b <- prot2codon('1ATU', 'A')
  c <- prot2codon("./pdb/1U8F.pdb", chain = 'O')
  d <- prot2codon('1A00', chain = 'A')
  e <- prot2codon('1F8A', 'B')

  expect_is(a, 'data.frame')
  expect_equal(sum(table(a$check)), nrow(a))
  expect_equal(ncol(a), 6)

  expect_is(b, 'data.frame')
  expect_equal(sum(table(b$check)), nrow(b))
  expect_equal(ncol(b), 6)

  expect_is(c, 'data.frame')
  expect_equal(sum(table(c$check)), nrow(c))
  expect_equal(ncol(c), 6)

  expect_is(d, 'data.frame')
  expect_equal(nrow(d), 141)
  expect_equal(ncol(d), 6)
  expect_equal(sum(table(d$check)), nrow(d))

  expect_is(e, 'data.frame')
  expect_equal(nrow(e), 155)
  expect_equal(ncol(e), 6)
  expect_equal(sum(table(e$check)), nrow(e) - 4)

})


## ---------------------------------------------- ##
#               Testing id.mapping                 #
## ---------------------------------------------- ##
test_that('id.mapping() works properly when pdb -> uniprot', {

  skip_on_cran()
  skip_on_travis()

  pdb_up <- id.mapping('3cwm', 'pdb','uniprot')
  pdb_up_m <- id.mapping('2occ', 'pdb', 'uniprot')

  expect_equal(pdb_up, 'P01009')
  expect_is(pdb_up_m, 'character')
  expect_equal(length(pdb_up_m), 13)
  expect_true('P00415' %in% pdb_up_m)
})


test_that('id.mapping() works properly when up -> pdb', {

  skip_on_cran()
  skip_on_travis()

  a <- id.mapping('P01009', 'uniprot', 'pdb')
  b <- id.mapping('P00415', 'uniprot', 'pdb')

  expect_is(a, 'character')
  expect_true('3CWM' %in% a)
  expect_is(b, 'character')
  expect_true('2OCC' %in% b)
})


test_that('id.mapping() works properly when up -> kegg', {

  skip_on_cran()
  skip_on_travis()

  up_kegg <- id.mapping('P01009', 'uniprot', 'kegg', 'human')

  expect_equivalent(up_kegg, 'hsa:5265')
})


test_that('id.mapping() works properly when kegg -> up', {

  skip_on_cran()
  skip_on_travis()

  kegg_up <- id.mapping('hsa:5265', 'kegg', 'uniprot')

  expect_is(kegg_up, 'character')
  expect_true("P01009" %in% kegg_up)

})


test_that('id.mapping() works properly when pdb -> kegg', {

  skip_on_cran()
  skip_on_travis()

  a <- id.mapping('3cwm', 'pdb','kegg', 'human')
  b <- id.mapping('2occ', 'pdb', 'kegg', 'cow')

  expect_is(a, 'character')
  expect_equivalent(a, "hsa:5265")
  expect_is(b, 'character')
  expect_true("bta:281090" %in% b)
})


test_that('id.mapping() works properly when kegg <- pdb', {

  skip_on_cran()
  skip_on_travis()

  a <- id.mapping('hsa:5265', 'kegg','pdb')
  b <- id.mapping('bta:281090', 'kegg','pdb')

  expect_is(a, 'character')
  expect_true('3CWM' %in% a)
  expect_is(b, 'character')
  expect_true('2OCC' %in% b)
})


## ---------------------------------------------- ##
#            Testing id.features                   #
## ---------------------------------------------- ##
test_that("id.features() works properly",{

  skip_on_cran()
  skip_on_travis()

  a <- id.features('P01009')
  b <- id.features('P01009', features = 'ec,keywords,database(PDB)')

  expect_is(a, 'list')
  expect_equal(length(a), 5)
  expect_equal(a$Status, "reviewed")
  expect_is(b, 'list')
  expect_equal(length(b), 8)
  expect_equal(a$Organism, b$Organism)
})

## ---------------------------------------------- ##
#           Testing species.mapping                #
## ---------------------------------------------- ##
test_that("species.mapping works properly",{

  skip_on_cran()
  skip_on_travis()

  a <- species.mapping('P01009')
  b <- species.mapping('2OCC', db = 'pdb')

  expect_is(a, 'character')
  expect_equal(a, "Homo sapiens")
  expect_is(b, 'character')
  expect_equal(b, "Bos taurus")
})
