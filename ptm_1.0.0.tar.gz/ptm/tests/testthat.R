library(testthat)
library(ptm)

# if (!require("visualTest")) install.packages("visualTest")
# if (!require("visualTest")) source("https://install-github.me/mangothecat/visualTest")
# library(visualTest)

test_check("ptm")
