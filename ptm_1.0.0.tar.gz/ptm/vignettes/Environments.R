## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(ptm)

## -----------------------------------------------------------------------------
library(ptm)
data <- meto.search(highthroughput.group = TRUE,
                    bodyguard.group = FALSE,
                    regulatory.group = FALSE,
                    organism = 'Homo sapiens',
                    oxidant = 'H2O2')


## ---- echo=FALSE, results='asis'----------------------------------------------
knitr::kable(data[1:10,1:3])

## -----------------------------------------------------------------------------
table(data$met_vivo_vitro)

## -----------------------------------------------------------------------------
data <- data[which(data$met_vivo_vitro == 'vivo'), c(1,3)]

## -----------------------------------------------------------------------------
env.extract('A2RRP1',
            db = 'uniprot',
            c = 2042,
            r = 10,
            ctr = 'random')

## -----------------------------------------------------------------------------
MetO_sites_A2RRP1 <- data$met_pos[which(data$prot_id == "A2RRP1")]

## -----------------------------------------------------------------------------
MetO_sites_A2RRP1

## -----------------------------------------------------------------------------
env.extract('A2RRP1',
            db = 'uniprot',
            c = 2042,
            r = 10,
            ctr = 'random',
            exclude = c(2204))

## -----------------------------------------------------------------------------
data$MetOsites <- NA
for (i in 1:nrow(data)){
  target <- data$prot_id[i]
  data$MetOsites[i] <- list(data$met_pos[which(data$prot_id == target)])
}

## -----------------------------------------------------------------------------
for (i in 1:3){
  ## -------- db = uniprot ----------- ##
  uniprot_ti <- Sys.time()
  env <- env.extract(data$prot_id[i],
                     db = 'uniprot',
                     c = as.numeric(data$met_pos[i]),
                     r = 10,
                     ctr = 'random',
                     exclude = as.numeric(data$MetOsites[[i]]))
  uniprot_tf <- Sys.time()

  ## -------- db = metosite ----------- ##
  metosite_ti <- Sys.time()
  env <- env.extract(data$prot_id[i],
                     db = 'metosite',
                     c = as.numeric(data$met_pos[i]),
                     r = 10,
                     ctr = 'random',
                     exclude = as.numeric(data$MetOsites[[i]]))
   metosite_tf <- Sys.time()
}

paste("Computing time with uniprot:", uniprot_tf - uniprot_ti, "sec")
paste("Computing time with metosite:", metosite_tf - metosite_ti, "sec")

## -----------------------------------------------------------------------------
data$control <- data$positive <- NA
data <- data[which(data$met_pos != 1),] # To exclude initiation Met in 'positive' environments
for (i in 1:nrow(data)){
  # print(i) # to avoid loneliness uncomment this line
  env <- env.extract(data$prot_id[i],
                     db = 'metosite',
                     c = as.numeric(data$met_pos[i]),
                     r = 10,
                     ctr = 'random',
                     exclude = as.numeric(c(1,data$MetOsites[[i]])))
  # We have adde 1 to 'exclude' to exclude initiation Met in 'control' environments
  data$positive[i] <- env$Positive
  data$control[i] <- env$Control
}

## -----------------------------------------------------------------------------
positive <- env.matrices(data$positive)[[2]]
control <- env.matrices(data$control[which(data$control != "")] )[[2]]

## -----------------------------------------------------------------------------
positive <- positive[,-11]
control <- control[,-11]

## -----------------------------------------------------------------------------
Z <- env.Ztest(pos = positive, ctr = control, alpha = 0.001)

## -----------------------------------------------------------------------------
head(Z[[2]])

## -----------------------------------------------------------------------------
head(Z[[3]])

## ---- fig.show='hold'---------------------------------------------------------
env.plot(Z[[1]], aa = 'Y', pValue = 0.05)
env.plot(Z[[1]], aa = 'M', pValue = 0.05)

